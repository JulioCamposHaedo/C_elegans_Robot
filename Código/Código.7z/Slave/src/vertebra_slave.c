#include "vertebra_slave.h"
#include <xc.h>
#include "adc.h"
#include "i2c_slave.h"
#include "pwm1.h"
#include "pwm2.h"


static uint8_t flag_tmr1;
static uint8_t flag_i2c_reg;
static uint8_t flag_i2c_data;
static uint8_t write_reg;
static uint8_t write_data;

void TMR1_Slave_InterruptHandler(void){
    flag_tmr1 = 1;
}

uint8_t Get_TMR1_flag(void){
    return flag_tmr1;
}

void Set_TMR1_flag(void){
    flag_tmr1 = 0;
}
void I2C_reg_Slave_InterruptHandler(uint8_t reg){
    flag_i2c_reg = 1;
    write_reg = reg;
}

uint8_t Get_I2C_reg_flag(void){
    return flag_i2c_reg;
}

uint8_t Get_I2C_reg(void){
    return write_reg;
}

void Set_I2C_reg_flag(void){
    flag_i2c_reg = 0;
}
void I2C_data_Slave_InterruptHandler(void){
    flag_i2c_data = 1;
}

uint8_t Get_I2C_data_flag(void){
    return flag_i2c_data;
}

void Set_I2C_data_flag(void){
    flag_i2c_data = 0;
}


void Read_Ldr(void)
{
    uint16_t Luz,Luz2;
    Luz=ADC_GetConversion(LDR_Left);
    d1.dato1 = ADRESH;
    d1.dato2 = ADRESL;
    Luz2=ADC_GetConversion(LDR_Right);
    d1.dato3 = ADRESH;
    d1.dato4 = ADRESL;
}

void I2C_Read_Write(uint8_t data){
    uint8_t i2c_WrData;
    if(Get_I2C_data_flag())
    {
        d1.ciclo = data;
        PWM1_LoadDutyValue(d1.ciclo);
        PWM2_LoadDutyValue(90-d1.ciclo);
        Set_I2C_data_flag();
    }
    switch (data)
    {
        case 1:
            i2c_WrData = d1.dato1;
            break;
        case 2:
            i2c_WrData = d1.dato2;
            break;
        case 3:
            i2c_WrData = d1.dato3;
            break;
        case 4:
            i2c_WrData = d1.dato4;
            break;
        case PWM_REG:
            I2C_data_Slave_InterruptHandler();
            break;
            
        default:
            break;    
    }
    Data_to_master(i2c_WrData);
}
