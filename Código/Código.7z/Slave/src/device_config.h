#ifndef DEVICE_CONFIG_H
#define	DEVICE_CONFIG_H

#define _XTAL_FREQ 2000000

#endif	/* DEVICE_CONFIG_H */
