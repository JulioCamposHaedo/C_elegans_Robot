#ifndef VERTEBRA_H
#define	VERTEBRA_H

#include <xc.h>   
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#define PWM_REG 15// Direccion de memoria de PWM

/**
 * \brief Handler de la interrupci�n del TMR1
 *
 * \param[in] Ninguno
 *
 * \return Vac�o
 */
void TMR1_Slave_InterruptHandler(void);

/**
 * \brief Obtiene el estado del flag del handler de interrupci�n de TMR1
 *
 * \param[in] Ninguno
 *
 * \return Estado del flag
 */
uint8_t Get_TMR1_flag(void);

/**
 * \brief Resetea el estado del flag del handler de interrupci�n de TMR1
 *
 * \param[in] Ninguno
 *
 * \return Vac�o
 */
void Set_TMR1_flag(void);

/**
 * \brief Handler de la interrupci�n del I2C y almacena el registro de escritura
 *
 * \param[in] reg- registro al cual el master quiere escribir
 *
 * \return Vac�o
 */
void I2C_reg_Slave_InterruptHandler(uint8_t reg);

/**
 * \brief Obtiene el estado del flag del handler de interrupci�n de I2C
 *
 * \param[in] Ninguno
 *
 * \return Estado del flag
 */
uint8_t Get_I2C_reg_flag(void);

/**
 * \brief Obtiene el valor del registro del handler de interrupci�n de I2C
 *
 * \param[in] Ninguno
 *
 * \return Estado del flag
 */
uint8_t Get_I2C_reg(void);

/**
 * \brief Resetea el estado del flag del handler de interrupci�n de I2C
 *
 * \param[in] Ninguno
 *
 * \return Vac�o
 */
void Set_I2C_reg_flag(void);

/**
 * \brief Rutina de lectura y escritura en la interrupci�n de I2C
 *
 * \param[in] Ninguno
 *
 * \return Vac�o
 */
void I2C_Read_Write(uint8_t data);

/**
 * \brief Rutina de lectura de los sensores
 *
 * \param[in] Ninguno
 *
 * \return Vac�o
 */

void Read_Ldr(void);

#endif // VERTEBRA_H

